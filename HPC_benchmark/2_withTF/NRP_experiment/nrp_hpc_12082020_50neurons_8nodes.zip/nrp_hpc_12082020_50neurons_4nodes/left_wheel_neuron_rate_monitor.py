@nrp.NeuronMonitor(nrp.brain.actors[1], nrp.population_rate)
def left_wheel_neuron_rate_monitor(t):
    return True

